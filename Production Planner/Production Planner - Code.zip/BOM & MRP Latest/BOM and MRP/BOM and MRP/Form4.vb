﻿Public Class Form4

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Me.Hide()
    End Sub

    Private Sub btnProceed_MouseEnter(sender As Object, e As EventArgs) Handles btnProceed.MouseEnter
        btnProceed.BackColor = Color.MediumBlue
    End Sub

    Private Sub btnProceed_MouseLeave(sender As Object, e As EventArgs) Handles btnProceed.MouseLeave
        btnProceed.BackColor = Color.RoyalBlue
    End Sub

End Class