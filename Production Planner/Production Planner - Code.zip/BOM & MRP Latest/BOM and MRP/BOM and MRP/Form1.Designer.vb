﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtper = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtcomp = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label = New System.Windows.Forms.Label()
        Me.txtsheet = New System.Windows.Forms.TextBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnlinput = New System.Windows.Forms.Panel()
        Me.btnProceed = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.pnlcomp = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtparent = New System.Windows.Forms.TextBox()
        Me.txtamount = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtchild = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.InstructionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.pnlinput.SuspendLayout()
        Me.pnlcomp.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtper
        '
        Me.txtper.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtper.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtper.Location = New System.Drawing.Point(227, 88)
        Me.txtper.Multiline = True
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(113, 22)
        Me.txtper.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(222, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 15)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Number of Periods"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(29, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(143, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Number of Components"
        '
        'txtcomp
        '
        Me.txtcomp.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtcomp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtcomp.Location = New System.Drawing.Point(32, 88)
        Me.txtcomp.Multiline = True
        Me.txtcomp.Name = "txtcomp"
        Me.txtcomp.Size = New System.Drawing.Size(145, 22)
        Me.txtcomp.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.RoyalBlue
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(880, 28)
        Me.MenuStrip1.TabIndex = 68
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResetToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Font = New System.Drawing.Font("Californian FB", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(45, 24)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ResetToolStripMenuItem
        '
        Me.ResetToolStripMenuItem.Name = "ResetToolStripMenuItem"
        Me.ResetToolStripMenuItem.Size = New System.Drawing.Size(124, 26)
        Me.ResetToolStripMenuItem.Text = "&Reset"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(124, 26)
        Me.ExitToolStripMenuItem.Text = "&Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.InstructionsToolStripMenuItem})
        Me.HelpToolStripMenuItem.Font = New System.Drawing.Font("Californian FB", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(53, 24)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.AboutToolStripMenuItem.Text = "&About"
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label.Location = New System.Drawing.Point(29, 28)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(107, 15)
        Me.Label.TabIndex = 69
        Me.Label.Text = "Worksheet Title:"
        '
        'txtsheet
        '
        Me.txtsheet.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtsheet.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtsheet.Location = New System.Drawing.Point(152, 26)
        Me.txtsheet.Multiline = True
        Me.txtsheet.Name = "txtsheet"
        Me.txtsheet.Size = New System.Drawing.Size(188, 24)
        Me.txtsheet.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Californian FB", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(38, 54)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(360, 29)
        Me.Label8.TabIndex = 74
        Me.Label8.Text = "Material Requirements Planning"
        '
        'pnlinput
        '
        Me.pnlinput.Controls.Add(Me.txtper)
        Me.pnlinput.Controls.Add(Me.txtsheet)
        Me.pnlinput.Controls.Add(Me.Label)
        Me.pnlinput.Controls.Add(Me.Label1)
        Me.pnlinput.Controls.Add(Me.txtcomp)
        Me.pnlinput.Controls.Add(Me.Label4)
        Me.pnlinput.Location = New System.Drawing.Point(28, 104)
        Me.pnlinput.Name = "pnlinput"
        Me.pnlinput.Size = New System.Drawing.Size(376, 132)
        Me.pnlinput.TabIndex = 1
        '
        'btnProceed
        '
        Me.btnProceed.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProceed.Location = New System.Drawing.Point(89, 254)
        Me.btnProceed.Name = "btnProceed"
        Me.btnProceed.Size = New System.Drawing.Size(111, 33)
        Me.btnProceed.TabIndex = 2
        Me.btnProceed.Text = "&Proceed"
        Me.btnProceed.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(244, 254)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(111, 33)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'pnlcomp
        '
        Me.pnlcomp.Controls.Add(Me.Label12)
        Me.pnlcomp.Controls.Add(Me.txtparent)
        Me.pnlcomp.Controls.Add(Me.txtamount)
        Me.pnlcomp.Controls.Add(Me.Label9)
        Me.pnlcomp.Controls.Add(Me.Label10)
        Me.pnlcomp.Controls.Add(Me.txtchild)
        Me.pnlcomp.Controls.Add(Me.Label11)
        Me.pnlcomp.Location = New System.Drawing.Point(472, 88)
        Me.pnlcomp.Name = "pnlcomp"
        Me.pnlcomp.Size = New System.Drawing.Size(376, 126)
        Me.pnlcomp.TabIndex = 70
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(163, 34)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(51, 30)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "connect" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtparent
        '
        Me.txtparent.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtparent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtparent.Location = New System.Drawing.Point(232, 39)
        Me.txtparent.Multiline = True
        Me.txtparent.Name = "txtparent"
        Me.txtparent.Size = New System.Drawing.Size(113, 22)
        Me.txtparent.TabIndex = 2
        '
        'txtamount
        '
        Me.txtamount.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtamount.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtamount.Location = New System.Drawing.Point(157, 84)
        Me.txtamount.Multiline = True
        Me.txtamount.Name = "txtamount"
        Me.txtamount.Size = New System.Drawing.Size(188, 24)
        Me.txtamount.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(34, 88)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(97, 15)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "Amount Needed"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(230, 17)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(114, 15)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Parent Component"
        '
        'txtchild
        '
        Me.txtchild.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtchild.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtchild.Location = New System.Drawing.Point(33, 39)
        Me.txtchild.Multiline = True
        Me.txtchild.Name = "txtchild"
        Me.txtchild.Size = New System.Drawing.Size(113, 22)
        Me.txtchild.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(28, 17)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(107, 15)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Child Component"
        '
        'btnConnect
        '
        Me.btnConnect.Font = New System.Drawing.Font("Californian FB", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnect.Location = New System.Drawing.Point(602, 230)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(108, 28)
        Me.btnConnect.TabIndex = 75
        Me.btnConnect.Text = "&Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'InstructionsToolStripMenuItem
        '
        Me.InstructionsToolStripMenuItem.Name = "InstructionsToolStripMenuItem"
        Me.InstructionsToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.InstructionsToolStripMenuItem.Text = "&Instructions"
        '
        'Form1
        '
        Me.AcceptButton = Me.btnProceed
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(880, 319)
        Me.Controls.Add(Me.pnlcomp)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnProceed)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.pnlinput)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Materials Requirement Planning"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.pnlinput.ResumeLayout(False)
        Me.pnlinput.PerformLayout()
        Me.pnlcomp.ResumeLayout(False)
        Me.pnlcomp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtper As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtcomp As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label As Label
    Friend WithEvents txtsheet As TextBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Label8 As Label
    Friend WithEvents pnlinput As Panel
    Friend WithEvents btnProceed As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents pnlcomp As Panel
    Friend WithEvents txtparent As TextBox
    Friend WithEvents txtamount As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtchild As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnConnect As Button
    Friend WithEvents InstructionsToolStripMenuItem As ToolStripMenuItem
End Class
