﻿Imports System.Windows.Forms
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports Microsoft.Office.Interop
Imports Microsoft.Office.Interop.Excel
Public Class Form1
    Dim oXL As New Excel.Application
    Dim strsheet As String
    Dim intper As Integer
    Dim intcomp As Integer
    Dim Ccounter As Integer
    Dim Rcounter As Integer
    Dim oWB As Excel.Workbook = oXL.Workbooks.Add
    Dim oSheet As Excel.Worksheet = oWB.Sheets(1)


    Private Sub TextBox_numbers_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcomp.KeyPress, txtper.KeyPress, txtamount.KeyPress, txtchild.KeyPress, txtparent.KeyPress
        If AscW(e.KeyChar) > 47 And AscW(e.KeyChar) < 58 Or AscW(e.KeyChar) = 8 Then
            'Blank statement to allow input  'Reject other characters by overriding e
        Else
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub btnProceed_Click_1(sender As Object, e As EventArgs) Handles btnProceed.Click

        If txtcomp.Text.Trim() = "" And txtper.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for both textbox!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtcomp.Focus()
        ElseIf txtcomp.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for components!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtcomp.Focus()
        ElseIf txtper.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for period!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtcomp.Focus()
        Else
            Try
                ' Get the default sheet
                strsheet = txtsheet.Text

                oSheet.Name = strsheet
                'Me.Hide()
                oXL.Visible = True
                intper = txtper.Text

                intcomp = txtcomp.Text
                For Rcounter = 0 To (intcomp - 1) * 9 Step 9 'pinaltan ko from intcomp to (intcomp-1) (reuben)
                    For periodcells = 1 To intper + 1 Step 1
                        oSheet.Cells(Rcounter + 4, periodcells + 3).value = "Period " & periodcells - 1
                    Next
                    With oSheet
                        .Cells(Rcounter + 3, 3).Value = “BOM line ” & Rcounter / 9 + 1
                        .Cells(5 + Rcounter, 3).Value = “Gross requirements”
                        .Cells(6 + Rcounter, 3).Value = “Scheduled Receipts”
                        .Cells(7 + Rcounter, 3).Value = “On Hand Inventory”
                        .Cells(8 + Rcounter, 3).Value = “NET POQ Req”
                        .Cells(9 + Rcounter, 3).Value = “Planned Receipt”
                        .Cells(10 + Rcounter, 3).Value = “Planned Orders”
                        .Cells(3 + Rcounter, 4).Value = "Lead Time"
                        .Cells(3 + Rcounter, 6).Value = "Safety Stock"
                        .Cells(3 + Rcounter, 8).Value = "Lot Size"

                    End With
                    'On Hand Inventory:
                    For Ccounter = 0 To intper - 1 Step 1
                        oSheet.Cells(Rcounter + 7, Ccounter + 5).formula = "=IF((" & Chr(Ccounter + 68) & Rcounter + 6 & "+" & Chr(Ccounter + 68) & Rcounter + 7 & "-" & Chr(Ccounter + 68) & Rcounter + 5 & ")<0*Or(" & Chr(Ccounter + 68) & Rcounter + 5 & "<" & Chr(Ccounter + 68) & Rcounter + 7 & "),0," & Chr(Ccounter + 68) & Rcounter + 6 & "+" & Chr(Ccounter + 68) & Rcounter + 7 & "-" & Chr(Ccounter + 68) & Rcounter + 5 & ")"
                        oSheet.Cells(Rcounter + 7, 4).formula = "=G" & Rcounter + 3
                    Next

                    'NET POQ Req and Planned receipts:

                    For Ccounter = 0 To intper - 1 Step 1
                        oSheet.Cells(Rcounter + 8, Ccounter + 5).formula = "=IF((" & Chr(Ccounter + 69) & Rcounter + 5 & ">0)*Or(" & Chr(Ccounter + 69) & Rcounter + 5 & ">" & Chr(Ccounter + 69) & Rcounter + 7 & ")," & Chr(Ccounter + 69) & Rcounter + 5 & "-" & Chr(Ccounter + 69) & Rcounter + 7 & ",0)"
                        oSheet.Cells(Rcounter + 9, Ccounter + 5).FOrmula = "=(" & Chr(Ccounter + 69) & Rcounter + 8 & ")"
                        oSheet.Cells(Rcounter + 10, Ccounter + 5).formula = "=INDEX(" & Chr(Ccounter + 69) & Rcounter + 9 & ":" & Chr(68) & Chr(90) & Rcounter + 9 & ",1,$" & Chr(69) & Rcounter + 3 & "+1"
                    Next


                    'Planned Orders:
                    'For Ccounter = 0 To intper - 1 Step 1
                    'oSheet.Cells(Rcounter + 10, Ccounter + 5).formula = "=INDEX(" & Chr(Ccounter + 69) & Rcounter + 7 & ":" & Chr(65 + intper) & Rcounter + 7 & ",1," & Chr(69) & Rcounter + 3 & "+1)"
                    'Next
                Next
                oWB.Saved = True 'tells Excel that oWB has been saved 


                oSheet.Columns.AutoFit()
                oSheet.Rows.AutoFit()
                txtchild.Enabled = True
                txtparent.Enabled = True
                txtamount.Enabled = True
                btnConnect.Enabled = True
                txtsheet.Enabled = False
                txtcomp.Enabled = False
                txtper.Enabled = False
                btnProceed.Enabled = False
                Me.TopMost = True
                Me.BringToFront()
                Me.Activate()
                Me.TopMost = False
                'Form1.Show()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtchild.Enabled = False
        txtparent.Enabled = False
        txtamount.Enabled = False
        btnConnect.Enabled = False
        pnlinput.BackColor = Color.White
        RoundPanelCorners(pnlinput, 20)
        pnlcomp.BackColor = Color.White
        RoundPanelCorners(pnlcomp, 20)
        btnProceed.BackColor = Color.RoyalBlue
        btnProceed.ForeColor = Color.White
        btnProceed.FlatStyle = FlatStyle.Flat
        btnProceed.FlatAppearance.BorderSize = 0
        btnProceed.UseVisualStyleBackColor = False
        btnReset.BackColor = Color.RoyalBlue
        btnReset.ForeColor = Color.White
        btnReset.FlatStyle = FlatStyle.Flat
        btnReset.FlatAppearance.BorderSize = 0
        btnReset.UseVisualStyleBackColor = False
        btnConnect.BackColor = Color.RoyalBlue
        btnConnect.ForeColor = Color.White
        btnConnect.FlatStyle = FlatStyle.Flat
        btnConnect.FlatAppearance.BorderSize = 0
        btnConnect.UseVisualStyleBackColor = False
    End Sub

    Private Sub pnlinput_MouseEnter(sender As Object, e As EventArgs) Handles Label.MouseEnter, pnlinput.MouseEnter, txtsheet.MouseEnter, txtcomp.MouseEnter, txtper.MouseEnter, Label1.MouseEnter, Label4.MouseEnter
        pnlinput.BackColor = Color.RoyalBlue
        Label1.ForeColor = Color.White
        Label.ForeColor = Color.White
        Label4.ForeColor = Color.White
    End Sub

    Private Sub pnlinput_MouseLeave(sender As Object, e As EventArgs) Handles pnlinput.MouseLeave
        pnlinput.BackColor = Color.White
        Label1.ForeColor = Color.Black
        Label.ForeColor = Color.Black
        Label4.ForeColor = Color.Black
    End Sub

    Private Sub pnlcomp_MouseEnter(sender As Object, e As EventArgs) Handles pnlcomp.MouseEnter, txtparent.MouseEnter, txtchild.MouseEnter, txtamount.MouseEnter, Label10.MouseEnter, Label11.MouseEnter, Label12.MouseEnter, Label9.MouseEnter
        pnlcomp.BackColor = Color.RoyalBlue
        Label9.ForeColor = Color.White
        Label10.ForeColor = Color.White
        Label11.ForeColor = Color.White
        Label12.ForeColor = Color.White
    End Sub

    Private Sub pnlcomp_MouseLeave(sender As Object, e As EventArgs) Handles pnlcomp.MouseLeave
        pnlcomp.BackColor = Color.White
        Label9.ForeColor = Color.Black
        Label10.ForeColor = Color.Black
        Label11.ForeColor = Color.Black
        Label12.ForeColor = Color.Black
    End Sub

    Private Sub btnProceed_MouseEnter(sender As Object, e As EventArgs) Handles btnProceed.MouseEnter
        btnProceed.BackColor = Color.MediumBlue
    End Sub

    Private Sub btnProceed_MouseLeave(sender As Object, e As EventArgs) Handles btnProceed.MouseLeave
        btnProceed.BackColor = Color.RoyalBlue
    End Sub

    Private Sub btnReset_MouseEnter(sender As Object, e As EventArgs) Handles btnReset.MouseEnter
        btnReset.BackColor = Color.MediumBlue
    End Sub

    Private Sub btnReset_MouseLeave(sender As Object, e As EventArgs) Handles btnReset.MouseLeave
        btnReset.BackColor = Color.RoyalBlue
    End Sub
    Private Sub btnConnect_MouseEnter(sender As Object, e As EventArgs) Handles btnConnect.MouseEnter
        btnConnect.BackColor = Color.MediumBlue
    End Sub

    Private Sub btnConnect_MouseLeave(sender As Object, e As EventArgs) Handles btnConnect.MouseLeave
        btnConnect.BackColor = Color.RoyalBlue
    End Sub

    Private Sub txtsheet_MouseEnter(sender As Object, e As EventArgs) Handles txtsheet.MouseEnter
        txtsheet.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtsheet_MouseLeave(sender As Object, e As EventArgs) Handles txtsheet.MouseLeave
        txtsheet.BackColor = Color.WhiteSmoke
    End Sub
    Private Sub txtcomp_MouseEnter(sender As Object, e As EventArgs) Handles txtcomp.MouseEnter
        txtcomp.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtcomp_MouseLeave(sender As Object, e As EventArgs) Handles txtcomp.MouseLeave
        txtcomp.BackColor = Color.WhiteSmoke
    End Sub
    Private Sub txtper_MouseEnter(sender As Object, e As EventArgs) Handles txtper.MouseEnter
        txtper.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtper_MouseLeave(sender As Object, e As EventArgs) Handles txtper.MouseLeave
        txtper.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub txtchild_MouseEnter(sender As Object, e As EventArgs) Handles txtchild.MouseEnter
        txtchild.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtchild_MouseLeave(sender As Object, e As EventArgs) Handles txtchild.MouseLeave
        txtchild.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub txtparent_MouseEnter(sender As Object, e As EventArgs) Handles txtparent.MouseEnter
        txtparent.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtparent_MouseLeave(sender As Object, e As EventArgs) Handles txtparent.MouseLeave
        txtparent.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub txtamount_MouseEnter(sender As Object, e As EventArgs) Handles txtamount.MouseEnter
        txtamount.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtamount_MouseLeave(sender As Object, e As EventArgs) Handles txtamount.MouseLeave
        txtamount.BackColor = Color.WhiteSmoke
    End Sub
    Sub RoundPanelCorners(ByVal panel As Panel, ByVal radius As Integer)
        Dim path As New GraphicsPath()
        path.StartFigure()
        path.AddArc(New System.Drawing.Rectangle(0, 0, radius, radius), 180, 90)
        path.AddArc(New System.Drawing.Rectangle(panel.Width - radius, 0, radius, radius), 270, 90)
        path.AddArc(New System.Drawing.Rectangle(panel.Width - radius, panel.Height - radius, radius, radius), 0, 90)
        path.AddArc(New System.Drawing.Rectangle(0, panel.Height - radius, radius, radius), 90, 90)
        path.CloseFigure()
        panel.Region = New Region(path)
    End Sub

    Private Sub btnConnect_Click(sender As Object, e As EventArgs)
        Try
            Dim child As Integer = txtchild.Text
            Dim parent As Integer = txtparent.Text
            Dim Amount As Integer = txtamount.Text
            Dim arrayP(intper) As Integer
            Dim arrayC(intper) As Integer

            For intcounter = 0 To intper
                arrayP(intcounter) = oSheet.Cells((parent * 9), intcounter + 3).value
            Next

            For intcounter = 0 To intper
                arrayC(intcounter) = Change(arrayP, intcounter, Amount)
            Next

            For intR1 As Integer = 3 To (intper + 3)
                oSheet.Cells((parent * 9), intR1).value = arrayC(intR1 - 3)
            Next
            oXL.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Function Change(ByRef arrayP() As Integer, ByRef intcounter As Integer, ByVal Amount As Integer) As Integer
        Change = Amount * (arrayP(intcounter))
    End Function

    Private Sub btnConnect_Click_1(sender As Object, e As EventArgs) Handles btnConnect.Click

        If txtchild.Text.Trim() = "" And txtparent.Text.Trim() = "" And txtamount.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for all inputs!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtparent.Focus()
        ElseIf txtchild.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for child component!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtchild.Focus()
        ElseIf txtparent.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for parent component!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtparent.Focus()
        ElseIf txtamount.Text.Trim() = "" Then
            MessageBox.Show("Please input a non-zero positive integer value for amount!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtcomp.Focus()
        Else

            Dim child As Integer = txtchild.Text
            Dim parent As Integer = txtparent.Text
            Dim amount As Integer = txtamount.Text

            oSheet.Cells((child - 1) * 9 + 3, 1).Formula = "=" & amount

            For inchar As Integer = 0 To intper - 1
                oSheet.Cells((child * 9) - 4, inchar + 5).formula = "=(" & Chr(inchar + 69) & (parent * 9) + 1 & ")*$A$" & (child - 1) * 9 + 3
            Next

        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        If MessageBox.Show("Do you want to exit the program?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbYes Then
            oXL.Quit()
            oSheet = Nothing
            oWB = Nothing
            oXL = Nothing
            End
        End If

        'Code to exit the form using the message box. 

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click, ResetToolStripMenuItem.Click
        txtamount.Clear()
        txtchild.Clear()
        txtcomp.Clear()
        txtparent.Clear()
        txtper.Clear()
        txtsheet.Clear()

        oSheet.Range("A1:ZZ1000").Value = ""

        oWB.Saved = True

        txtcomp.Enabled = True
        txtper.Enabled = True
        txtsheet.Enabled = True
        btnProceed.Enabled = True
        txtchild.Enabled = False
        txtparent.Enabled = False
        txtamount.Enabled = False
        btnConnect.Enabled = False
        pnlinput.BackColor = Color.White
        RoundPanelCorners(pnlinput, 20)
        pnlcomp.BackColor = Color.White
        RoundPanelCorners(pnlcomp, 20)
        btnProceed.BackColor = Color.RoyalBlue
        btnProceed.ForeColor = Color.White
        btnProceed.FlatStyle = FlatStyle.Flat
        btnProceed.FlatAppearance.BorderSize = 0
        btnProceed.UseVisualStyleBackColor = False
        btnReset.BackColor = Color.RoyalBlue
        btnReset.ForeColor = Color.White
        btnReset.FlatStyle = FlatStyle.Flat
        btnReset.FlatAppearance.BorderSize = 0
        btnReset.UseVisualStyleBackColor = False
        btnConnect.BackColor = Color.RoyalBlue
        btnConnect.ForeColor = Color.White
        btnConnect.FlatStyle = FlatStyle.Flat
        btnConnect.FlatAppearance.BorderSize = 0
        btnConnect.UseVisualStyleBackColor = False
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        FormAbout.Show()
    End Sub

    Private Sub InstructionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InstructionsToolStripMenuItem.Click
        Form4.Show()
    End Sub
End Class
