﻿Public Class Form2

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim child As Integer = txtchild.Text
        Dim parent As Integer = txtparent.Text
        Dim Amount As Integer = txtamount.Text
        Dim arrayP(intper) As Integer
        Dim arrayC(intper) As Integer

        For intcounter = 0 To intper
            arrayP(intcounter) = oSheet.Cells((parent * 9), intcounter + 3).value
        Next

        For intcounter = 0 To intper
            arrayC(intcounter) = Change(arrayP, intcounter, Amount)
        Next

        For intR1 As Integer = 3 To (intper + 3)
            oSheet.Cells((parent * 9), intR1).value = arrayC(intR1 - 3)
        Next
        oXL.Visible = False
    End Sub

    Function Change(ByRef arrayP() As Integer, ByRef intcounter As Integer, ByVal Amount As Integer) As Integer
        Change = Amount * (arrayP(intcounter))
    End Function



End Class