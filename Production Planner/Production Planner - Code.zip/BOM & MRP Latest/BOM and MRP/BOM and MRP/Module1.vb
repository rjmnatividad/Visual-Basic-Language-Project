﻿Imports Microsoft.Office.Interop

Module Globals
    Public oXL As Excel.Application
    Public oWB As Excel.Workbook
    Public oSheet As Excel.Worksheet

    Public intper As Integer

End Module

